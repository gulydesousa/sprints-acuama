--TRUNCATE TABLE dbo.otDocumentos


--SELECT * FROM dbo.otDocumentos

--SELECT * into tt1 FROM otDocumentos 

--SELECT * FROM tt1
--SELECT * FROM tt

--INSERT INTO otDocumentos SELECT 1, 80, 22995, 'CCR', *, 'prueba imagen retirada'  FROM ACUAMA_RIBADESELLA_DESA.dbo.imagenes
--INSERT INTO otDocumentos SELECT 1, 80, 22997, 'CCR', *, 'prueba imagen retirada'  FROM ACUAMA_RIBADESELLA_DESA.dbo.imagenes

--INSERT INTO dbo.otDocumentos (otdSerScd,otdSerCod,otdNum, otdTipoCodigo, otdDocumento, otdDescripcion)   SELECT * FROM tt