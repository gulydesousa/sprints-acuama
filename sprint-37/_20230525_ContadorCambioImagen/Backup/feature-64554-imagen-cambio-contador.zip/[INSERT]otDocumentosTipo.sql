--TRUNCATE TABLE otDocumentoTipo
INSERT INTO otDocumentoTipo VALUES ('CCR', 'Lectura de Retirada', 'image/jpeg', 2)
INSERT INTO otDocumentoTipo VALUES ('OTRO', 'Otro', 'image/jpeg', 10)
